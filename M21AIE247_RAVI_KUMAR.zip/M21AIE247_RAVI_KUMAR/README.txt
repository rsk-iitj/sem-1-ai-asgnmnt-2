How to run:
**********************************************************************************************
1. It is just one simple python file, run it using python or python3 & it will ask for user input.
2. Input the expression & it will show result on std out device that is console. 
